from django.contrib import admin
from pgsApp import models

# Register your models here.
admin.site.register(models.Gallery)

